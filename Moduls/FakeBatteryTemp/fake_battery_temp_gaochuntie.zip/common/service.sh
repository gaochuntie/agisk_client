#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 15
mkdir -p /data/agisk/battery
echo 320 >/data/agisk/battery/temp
mount --bind /data/agisk/battery/temp /sys/class/power_supply/battery/temp
while [ 1 ]; do
    echo 320 >/data/agisk/battery/temp
    echo "test"
    sleep 30
done
